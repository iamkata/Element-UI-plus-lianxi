
//按需导入
import { ElButton } from 'element-plus'
//默认导入
import lang from 'element-plus/lib/locale/lang/zh-cn'
import locale from 'element-plus/lib/locale'

//默认导出
export default (app) => {
  locale.use(lang)
  app.use(ElButton)
}
